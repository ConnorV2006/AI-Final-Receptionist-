"""initial tables

Revision ID: 0001_initial
Revises: 
Create Date: 20251002_0817

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = '0001_initial'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('role',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=32), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('name')
    )

    op.create_table('user',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('email', sa.String(length=255), nullable=False),
        sa.Column('name', sa.String(length=120), nullable=False),
        sa.Column('password_hash', sa.String(length=255), nullable=False),
        sa.Column('role_id', sa.Integer(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['role_id'], ['role.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_user_email'), 'user', ['email'], unique=True)

    op.create_table('clinic',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('slug', sa.String(length=64), nullable=False),
        sa.Column('name', sa.String(length=120), nullable=False),
        sa.Column('twilio_number', sa.String(length=20), nullable=True),
        sa.Column('twilio_sid', sa.String(length=64), nullable=True),
        sa.Column('_twilio_token', sa.LargeBinary(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_clinic_slug'), 'clinic', ['slug'], unique=True)

    op.create_table('clinic_user',
        sa.Column('clinic_id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.ForeignKeyConstraint(['clinic_id'], ['clinic.id'], ),
        sa.ForeignKeyConstraint(['user_id'], ['user.id'], ),
        sa.PrimaryKeyConstraint('clinic_id', 'user_id')
    )

    op.create_table('call_log',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('clinic_id', sa.Integer(), nullable=False),
        sa.Column('caller_number', sa.String(length=20), nullable=True),
        sa.Column('started_at', sa.DateTime(), nullable=True),
        sa.Column('status', sa.String(length=32), nullable=True),
        sa.Column('recording_url', sa.String(length=512), nullable=True),
        sa.Column('transcript', sa.Text(), nullable=True),
        sa.Column('sentiment', sa.String(length=64), nullable=True),
        sa.ForeignKeyConstraint(['clinic_id'], ['clinic.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('ix_call_log_clinic_id', 'call_log', ['clinic_id'])

    op.create_table('message_log',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('clinic_id', sa.Integer(), nullable=False),
        sa.Column('from_number', sa.String(length=20), nullable=True),
        sa.Column('to_number', sa.String(length=20), nullable=True),
        sa.Column('body', sa.Text(), nullable=True),
        sa.Column('direction', sa.String(length=16), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['clinic_id'], ['clinic.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('ix_message_log_clinic_id', 'message_log', ['clinic_id'])

    op.create_table('recording',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('call_log_id', sa.Integer(), nullable=False),
        sa.Column('recording_sid', sa.String(length=64), nullable=True),
        sa.Column('url', sa.String(length=512), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['call_log_id'], ['call_log.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    op.create_table('audit_log',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('actor_id', sa.Integer(), nullable=True),
        sa.Column('action', sa.String(length=128), nullable=False),
        sa.Column('details', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['actor_id'], ['user.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('ix_auditlog_created_at', 'audit_log', ['created_at'])

def downgrade():
    op.drop_index('ix_auditlog_created_at', table_name='audit_log')
    op.drop_table('audit_log')
    op.drop_table('recording')
    op.drop_index('ix_message_log_clinic_id', table_name='message_log')
    op.drop_table('message_log')
    op.drop_index('ix_call_log_clinic_id', table_name='call_log')
    op.drop_table('call_log')
    op.drop_table('clinic_user')
    op.drop_index(op.f('ix_clinic_slug'), table_name='clinic')
    op.drop_table('clinic')
    op.drop_index(op.f('ix_user_email'), table_name='user')
    op.drop_table('user')
    op.drop_table('role')
