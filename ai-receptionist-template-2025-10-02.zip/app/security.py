from cryptography.fernet import Fernet

fernet = None

def init_encryption(app):
    global fernet
    key = app.config.get("APP_ENC_KEY")
    if not key:
        app.logger.warning("APP_ENC_KEY not set. Generating a temporary key (NOT persisted).")
        key = Fernet.generate_key().decode()
        app.logger.warning(f"Save this key as APP_ENC_KEY to persist data: {key}")
    fernet = Fernet(key.encode()) if isinstance(key, str) else Fernet(key)

def encrypt(value: str):
    if value is None:
        return None
    return fernet.encrypt(value.encode())

def decrypt(token: bytes):
    if token is None:
        return None
    return fernet.decrypt(token).decode()
