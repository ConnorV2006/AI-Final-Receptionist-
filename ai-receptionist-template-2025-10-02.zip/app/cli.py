import click
from .extensions import db
from .models import User, Role, Clinic

def register_cli(app):
    @app.cli.command("seed-superuser")
    @click.option("--email", required=True)
    @click.option("--password", required=True)
    @click.option("--name", default="Admin")
    def seed_superuser(email, password, name):
        admin_role = Role.query.filter_by(name="admin").first()
        if not admin_role:
            admin_role = Role(name="admin")
            db.session.add(admin_role); db.session.commit()
        user = User.query.filter_by(email=email.lower()).first()
        if not user:
            user = User(email=email.lower(), name=name, role=admin_role)
            user.set_password(password)
            db.session.add(user); db.session.commit()
        click.echo(f"Admin user ready: {user.email}")

    @app.cli.command("create-clinic")
    @click.option("--slug", required=True)
    @click.option("--name", required=True)
    @click.option("--twilio-number", default=None)
    def create_clinic(slug, name, twilio_number):
        c = Clinic.query.filter_by(slug=slug).first()
        if c:
            click.echo("Clinic already exists"); return
        c = Clinic(slug=slug, name=name, twilio_number=twilio_number)
        db.session.add(c); db.session.commit()
        click.echo(f"Clinic created: {slug}")
