import logging
from flask import Flask
from .config import get_config
from .extensions import db, migrate, login_manager, csrf, limiter
from .security import init_encryption
from .blueprints.auth.routes import bp as auth_bp
from .blueprints.admin.routes import bp as admin_bp
from .blueprints.clinic.routes import bp as clinic_bp
from .blueprints.api.routes import bp as api_bp

def create_app():
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config.from_object(get_config())

    # Logging
    logging.basicConfig(level=logging.INFO)

    # Extensions
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    csrf.init_app(app)
    limiter.init_app(app)

    # Security headers
    @app.after_request
    def set_security_headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        resp.headers["Content-Security-Policy"] = app.config.get("CONTENT_SECURITY_POLICY")
        return resp

    # Encryption
    init_encryption(app)

    # Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp, url_prefix="/admin")
    app.register_blueprint(clinic_bp, url_prefix="/t")
    app.register_blueprint(api_bp, url_prefix="/twilio")

    @app.get("/")
    def index():
        return "<h1>AI Receptionist</h1><p><a href='/auth/login'>Login</a></p>"

    # CLI
    from .cli import register_cli
    register_cli(app)

    return app
