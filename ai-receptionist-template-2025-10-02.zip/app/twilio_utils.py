from functools import wraps
from flask import request, abort, current_app
from twilio.request_validator import RequestValidator

def verify_twilio_request(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        validator = RequestValidator(current_app.config.get("TWILIO_AUTH_TOKEN", ""))
        signature = request.headers.get("X-Twilio-Signature", "")
        # Most reliable: use request.url (includes query string) for verification
        url = request.url
        if not validator.validate(url, request.form, signature):
            current_app.logger.warning("Invalid Twilio signature for %s", request.path)
            abort(403)
        return f(*args, **kwargs)
    return wrapper
