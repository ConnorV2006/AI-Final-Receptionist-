from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired, Length

class ClinicSettingsForm(FlaskForm):
    name = StringField("Clinic Name", validators=[DataRequired(), Length(max=120)])
    twilio_number = StringField("Twilio Number", validators=[Length(max=20)])
    twilio_sid = StringField("Twilio SID", validators=[Length(max=64)])
    twilio_token = StringField("Twilio Auth Token", validators=[Length(max=64)])
    submit = SubmitField("Save")
