import os

class BaseConfig:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret")
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    REMEMBER_COOKIE_HTTPONLY = True
    WTF_CSRF_TIME_LIMIT = None
    RATELIMIT_DEFAULT = "200 per day"
    RATELIMIT_STORAGE_URI = "memory://"
    APP_BASE_URL = os.environ.get("APP_BASE_URL", "http://localhost:5000")
    CONTENT_SECURITY_POLICY = "default-src 'self'; img-src 'self' data:; script-src 'self'; style-src 'self' 'unsafe-inline'"
    TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID", "")
    TWILIO_AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN", "")
    APP_ENC_KEY = os.environ.get("APP_ENC_KEY")

class ProductionConfig(BaseConfig):
    SESSION_COOKIE_SECURE = True

class DevelopmentConfig(BaseConfig):
    DEBUG = True

def get_config():
    env = os.environ.get("FLASK_ENV", "production").lower()
    return DevelopmentConfig if env.startswith("dev") else ProductionConfig
