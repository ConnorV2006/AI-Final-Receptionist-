from flask import Blueprint, request, Response
from twilio.twiml.voice_response import VoiceResponse
from twilio.twiml.messaging_response import MessagingResponse
from ...extensions import db
from ...models import Clinic, CallLog, MessageLog, Recording
from ...twilio_utils import verify_twilio_request
from datetime import datetime

bp = Blueprint("api", __name__)

@bp.post("/voice/<slug>")
@verify_twilio_request
def inbound_call(slug):
    clinic = Clinic.query.filter_by(slug=slug).first_or_404()
    from_num = request.form.get("From")
    log = CallLog(clinic_id=clinic.id, caller_number=from_num, status="received", started_at=datetime.utcnow())
    db.session.add(log); db.session.commit()

    r = VoiceResponse()
    r.say("Hello. You have reached the clinic. Please leave a message after the tone.")
    r.record(max_length=120, play_beep=True, recording_status_callback=f"/twilio/voice/recording/{log.id}")
    r.hangup()
    return Response(str(r), mimetype="text/xml")

@bp.post("/voice/recording/<int:call_id>")
@verify_twilio_request
def recording_callback(call_id):
    log = CallLog.query.get_or_404(call_id)
    rec_url = request.form.get("RecordingUrl")
    rec_sid = request.form.get("RecordingSid")
    log.recording_url = rec_url
    db.session.add(Recording(call_log_id=log.id, recording_sid=rec_sid, url=rec_url))
    db.session.commit()
    return ("", 204)

@bp.post("/sms/<slug>")
@verify_twilio_request
def inbound_sms(slug):
    clinic = Clinic.query.filter_by(slug=slug).first_or_404()
    from_num = request.form.get("From")
    to_num = request.form.get("To")
    body = request.form.get("Body", "")
    msg = MessageLog(clinic_id=clinic.id, from_number=from_num, to_number=to_num, body=body, direction="inbound")
    db.session.add(msg); db.session.commit()

    resp = MessagingResponse()
    resp.message("Thanks for your message. We will get back to you shortly.")
    return Response(str(resp), mimetype="text/xml")
