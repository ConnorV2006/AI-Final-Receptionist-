from flask import Blueprint, render_template
from flask_login import login_required
from ...models import Clinic, CallLog, MessageLog

bp = Blueprint("clinic", __name__)

@bp.get("/<slug>/admin")
@login_required
def clinic_admin(slug):
    clinic = Clinic.query.filter_by(slug=slug).first_or_404()
    calls = CallLog.query.filter_by(clinic_id=clinic.id).order_by(CallLog.started_at.desc()).limit(50).all()
    messages = MessageLog.query.filter_by(clinic_id=clinic.id).order_by(MessageLog.created_at.desc()).limit(50).all()
    return render_template("clinic/admin_dashboard.html", clinic=clinic, calls=calls, messages=messages)
