from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from ...extensions import db
from ...models import Clinic, User, Role, AuditLog
from ...forms.clinic import ClinicSettingsForm

bp = Blueprint("admin", __name__)

def admin_required():
    return current_user.is_authenticated and (current_user.role and current_user.role.name == "admin")

@bp.before_request
def require_admin():
    if request.endpoint and request.blueprint == "admin":
        if not admin_required():
            return redirect(url_for("auth.login"))

@bp.get("/")
@login_required
def dashboard():
    clinics = Clinic.query.order_by(Clinic.created_at.desc()).all()
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template("admin/dashboard.html", clinics=clinics, users=users)

@bp.route("/clinics/new", methods=["GET", "POST"])
@login_required
def clinic_new():
    form = ClinicSettingsForm()
    if form.validate_on_submit():
        slug = form.name.data.lower().strip().replace(" ", "-")
        c = Clinic(slug=slug, name=form.name.data.strip())
        c.twilio_number = form.twilio_number.data or None
        c.twilio_sid = form.twilio_sid.data or None
        if form.twilio_token.data:
            c.set_twilio_token(form.twilio_token.data)
        db.session.add(c); db.session.commit()
        db.session.add(AuditLog(actor_id=current_user.id, action="create_clinic", details=c.slug))
        db.session.commit()
        flash("Clinic created.", "success")
        return redirect(url_for("admin.dashboard"))
    return render_template("admin/clinic_form.html", form=form)

@bp.route("/clinics/<int:clinic_id>/edit", methods=["GET", "POST"])
@login_required
def clinic_edit(clinic_id):
    clinic = Clinic.query.get_or_404(clinic_id)
    form = ClinicSettingsForm(obj=clinic)
    if form.validate_on_submit():
        clinic.name = form.name.data.strip()
        clinic.twilio_number = form.twilio_number.data or None
        clinic.twilio_sid = form.twilio_sid.data or None
        if form.twilio_token.data:
            clinic.set_twilio_token(form.twilio_token.data)
        db.session.commit()
        flash("Clinic updated.", "success")
        return redirect(url_for("admin.dashboard"))
    return render_template("admin/clinic_form.html", form=form, clinic=clinic)
