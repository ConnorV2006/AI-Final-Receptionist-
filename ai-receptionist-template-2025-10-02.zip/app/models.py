from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from sqlalchemy import Index
from .extensions import db
from .security import encrypt, decrypt

ClinicUser = db.Table(
    "clinic_user",
    db.Column("clinic_id", db.Integer, db.ForeignKey("clinic.id"), primary_key=True),
    db.Column("user_id", db.Integer, db.ForeignKey("user.id"), primary_key=True),
    db.UniqueConstraint("clinic_id", "user_id", name="uq_clinic_user"),
)

class Role(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(32), unique=True, nullable=False)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    name = db.Column(db.String(120), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey("role.id"))
    role = db.relationship("Role", backref="users")
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    clinics = db.relationship("Clinic", secondary=ClinicUser, backref="users")

    def set_password(self, raw: str):
        self.password_hash = generate_password_hash(raw)

    def check_password(self, raw: str) -> bool:
        return check_password_hash(self.password_hash, raw)

class Clinic(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    slug = db.Column(db.String(64), unique=True, nullable=False, index=True)
    name = db.Column(db.String(120), nullable=False)
    twilio_number = db.Column(db.String(20))
    twilio_sid = db.Column(db.String(64))
    _twilio_token = db.Column(db.LargeBinary, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_twilio_token(self, token: str):
        self._twilio_token = encrypt(token) if token else None

    def get_twilio_token(self) -> str:
        return decrypt(self._twilio_token) if self._twilio_token else None

class CallLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    clinic_id = db.Column(db.Integer, db.ForeignKey("clinic.id"), nullable=False, index=True)
    caller_number = db.Column(db.String(20))
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(32), default="received")
    recording_url = db.Column(db.String(512))
    transcript = db.Column(db.Text)
    sentiment = db.Column(db.String(64))

class MessageLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    clinic_id = db.Column(db.Integer, db.ForeignKey("clinic.id"), nullable=False, index=True)
    from_number = db.Column(db.String(20))
    to_number = db.Column(db.String(20))
    body = db.Column(db.Text)
    direction = db.Column(db.String(16))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Recording(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    call_log_id = db.Column(db.Integer, db.ForeignKey("call_log.id"), nullable=False, index=True)
    recording_sid = db.Column(db.String(64))
    url = db.Column(db.String(512))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class AuditLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    actor_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    action = db.Column(db.String(128), nullable=False)
    details = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    __table_args__ = (Index("ix_auditlog_created_at", "created_at"),)
